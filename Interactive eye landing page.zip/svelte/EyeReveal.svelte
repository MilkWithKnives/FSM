<!--
  EyeReveal.svelte — standalone eye-blink reveal overlay (Full Scope Media)
  Svelte 5 (runes). Fully self-contained: drop it in front of ANY site.

  Usage (in a layout or page, above/outside your site content):
    <script>
      import EyeReveal from '$lib/EyeReveal.svelte';
    </script>
    <EyeReveal onopened={() => console.log('revealed')} />
    ...your site...

  It renders position:fixed over the whole viewport, tracks the cursor
  (or finger on touch), blinks on click/tap, reveals the site through the
  opening eye, then removes itself from the DOM entirely.

  Props:
    follow    = 1            eye-follow strength (0–2)
    hint      = 'CLICK TO OPEN'   set '' to hide; label swaps to TAP on touch
    ink       = '#231f20'    eyelid/cover color
    line      = '#ffffff'    eye linework color
    zIndex    = 9999
    onopened  = () => {}     called when the reveal finishes
-->
<script>
  let {
    follow = 1,
    hint = 'CLICK TO OPEN',
    ink = '#231f20',
    line = '#ffffff',
    zIndex = 9999,
    onopened = () => {}
  } = $props();

  // unique mask id so two instances (or two sites in one shell) never collide
  const uid = 'eyeHole-' + Math.random().toString(36).slice(2, 9);

  let w = $state(typeof window !== 'undefined' ? window.innerWidth : 1920);
  let h = $state(typeof window !== 'undefined' ? window.innerHeight : 1080);

  let phase = $state('idle'); // idle | closing | opening | expanding | open
  let dx = $state(0), dy = $state(0), px = $state(0), py = $state(0);
  let coarse = $state(false); // touch device?
  let timers = [];

  $effect(() => {
    coarse = window.matchMedia('(pointer: coarse)').matches;
    return () => timers.forEach(clearTimeout);
  });

  // Eye geometry: the logo almond is ~88 x 46 user units centered at (287.22, 296.5).
  // Scale responsively: ~74% of viewport width, capped by 42% of height.
  const s = $derived(Math.min((w * 0.74) / 88, (h * 0.42) / 46));
  const cx = $derived(w / 2 + dx);
  const cy = $derived(h / 2 + dy);
  // how far the hole must grow to swallow the whole viewport
  const coverScale = $derived(Math.ceil((Math.max(w, h) * 2.6) / (46 * s)));

  function onPointerMove(e) {
    if (phase !== 'idle') return;
    const fx = Math.max(-0.5, Math.min(0.5, e.clientX / w - 0.5));
    const fy = Math.max(-0.5, Math.min(0.5, e.clientY / h - 0.5));
    dx = Math.round(fx * 2 * 2.75 * s);
    dy = Math.round(fy * 2 * 1.44 * s);
    px = Math.round(fx * 2 * 13 * follow * 10) / 10;
    py = Math.round(fy * 2 * 5.5 * follow * 10) / 10;
  }

  function open() {
    if (phase !== 'idle') return;
    dx = dy = px = py = 0;
    phase = 'closing';
    timers = [
      setTimeout(() => (phase = 'opening'), 130),
      setTimeout(() => (phase = 'expanding'), 860),
      setTimeout(() => { phase = 'open'; onopened(); }, 1650)
    ];
  }

  const later = $derived(phase === 'expanding' || phase === 'open');

  const hole = $derived(
    later
      ? { t: `translate(${cx}px, ${cy}px) scale(${coverScale}, ${coverScale})`, o: 1, trans: 'transform 780ms cubic-bezier(0.6, 0, 0.3, 1)' }
      : phase === 'opening'
        ? { t: `translate(${cx}px, ${cy}px) scale(1, 1)`, o: 1, trans: 'transform 430ms cubic-bezier(0.25, 0.65, 0.3, 1)' }
        : { t: `translate(${cx}px, ${cy}px) scale(1, 0.001)`, o: 0, trans: 'transform 0s' }
  );

  const eye = $derived(
    later
      ? { t: `translate(${cx}px, ${cy}px) scale(8) scaleY(1)`, o: 0, trans: 'transform 780ms cubic-bezier(0.6, 0, 0.3, 1), opacity 480ms 120ms ease-out' }
      : phase === 'opening'
        ? { t: `translate(${cx}px, ${cy}px) scale(1) scaleY(1)`, o: 1, trans: 'transform 430ms cubic-bezier(0.25, 0.65, 0.3, 1)' }
        : phase === 'closing'
          ? { t: `translate(${cx}px, ${cy}px) scale(1) scaleY(0.05)`, o: 1, trans: 'transform 120ms ease-in' }
          : { t: `translate(${cx}px, ${cy}px) scale(1) scaleY(1)`, o: 1, trans: 'transform 90ms linear' }
  );

  const irisO = $derived(phase === 'opening' || later ? 0 : 1);
  const hintText = $derived(coarse ? hint.replace(/CLICK/i, 'TAP') : hint);
</script>

<svelte:window bind:innerWidth={w} bind:innerHeight={h} />

{#if phase !== 'open'}
  <div class="eye-reveal" style="z-index: {zIndex};">
    <svg
      viewBox="0 0 {w} {h}"
      onpointermove={onPointerMove}
      onclick={open}
      role="button"
      tabindex="0"
      aria-label="Open site"
      onkeydown={(e) => (e.key === 'Enter' || e.key === ' ') && open()}
    >
      <mask id={uid} maskUnits="userSpaceOnUse" x="0" y="0" width={w} height={h}>
        <rect x="0" y="0" width={w} height={h} fill="#fff"/>
        <g style="transform: {hole.t}; transition: {hole.trans}; opacity: {hole.o};">
          <path transform="scale({s}) translate(-287.22 -296.5)" fill="#000"
            d="M245.65,299.61c18.28,17.07,38.03,22.15,58.72,15.1,13.23-4.51,22.65-12.8,25.33-15.33-20.53-16.76-40.93-21.76-60.67-14.87-12.7,4.43-21.08,12.66-23.38,15.11Z"/>
        </g>
      </mask>
      <rect x="0" y="0" width={w} height={h} fill={ink} mask="url(#{uid})"/>
      <g style="transform: {eye.t}; transition: {eye.trans}; opacity: {eye.o};">
        <g transform="scale({s}) translate(-287.22 -296.5)">
          <path fill={line} d="M286.81,319.69c-12.74,0-27.79-4.58-43.24-19.3l-.68-.65.61-.72c.37-.45,9.35-10.96,24.8-16.38,14.26-5,36.87-6.31,63.55,15.9l.83.69-.74.77c-.43.45-10.78,11.11-26.9,16.6-5.21,1.78-11.38,3.09-18.21,3.09ZM245.65,299.61c18.28,17.07,38.03,22.15,58.72,15.1,13.23-4.51,22.65-12.8,25.33-15.33-20.53-16.76-40.93-21.76-60.67-14.87-12.7,4.43-21.08,12.66-23.38,15.11Z"/>
          <path fill={line} d="M329.94,290.08c-17.93-15.8-37.88-20.62-59.29-14.33-16.04,4.71-26.93,14.23-27.04,14.33l-1.33-1.5c.45-.4,11.28-9.88,27.73-14.73,15.22-4.49,38.2-5.57,61.25,14.73l-1.32,1.5Z"/>
          <g class="iris" style="transform: translate({px}px, {py}px); opacity: {irisO};">
            <path fill={line} d="M287.37,313.49c-10.78,0-19.55-8.77-19.55-19.55,0-4.53,1.58-8.95,4.46-12.43l1.54,1.27c-2.58,3.13-4.01,7.1-4.01,11.16,0,9.68,7.87,17.55,17.55,17.55s17.55-7.87,17.55-17.55c0-3.66-1.12-7.17-3.23-10.15l1.63-1.16c2.36,3.32,3.6,7.23,3.6,11.31,0,10.78-8.77,19.55-19.55,19.55Z"/>
            <circle fill={line} cx="287.22" cy="292.79" r="12.1"/>
          </g>
        </g>
      </g>
    </svg>

    {#if hintText}
      <div class="hint" style="opacity: {phase === 'idle' ? 1 : 0}; color: {line};">{hintText}</div>
    {/if}
  </div>
{/if}

<style>
  .eye-reveal {
    position: fixed;
    inset: 0;
    /* dvh keeps it covering the real visible area on mobile browsers */
    height: 100dvh;
    touch-action: manipulation;
  }
  svg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    display: block;
    cursor: pointer;
    outline: none;
    -webkit-tap-highlight-color: transparent;
  }
  svg:focus-visible { outline: 2px solid #ec3013; outline-offset: -2px; }
  .iris { transition: transform 90ms linear, opacity 260ms ease-out; }
  .hint {
    position: absolute;
    left: 0; right: 0;
    bottom: max(6vh, calc(env(safe-area-inset-bottom) + 24px));
    pointer-events: none;
    text-align: center;
    font-family: 'Archivo', sans-serif;
    font-weight: 600;
    font-size: clamp(11px, 1.6vw, 15px);
    letter-spacing: 0.34em;
    transition: opacity 0.3s;
  }
  @media (prefers-reduced-motion: reduce) {
    .iris { transition: none; }
  }
</style>
