<!--
  EyeRevealLanding.svelte — example page using the standalone <EyeReveal /> overlay.
  The overlay is fully independent (EyeReveal.svelte) — put it in front of any site.
  This file is just the Full Scope Media landing content behind it, mobile-responsive.
-->
<script>
  import EyeReveal from './EyeReveal.svelte';

  let revealKey = $state(0); // bump to re-mount the overlay (replay)
</script>

{#key revealKey}
  <EyeReveal />
{/key}

<div class="root">
  <header class="nav">
    <div class="brand">
      <svg viewBox="240 270 94 52" class="mark" aria-label="Full Scope Media eye mark">
        <path fill="#201e1d" d="M286.81,319.69c-12.74,0-27.79-4.58-43.24-19.3l-.68-.65.61-.72c.37-.45,9.35-10.96,24.8-16.38,14.26-5,36.87-6.31,63.55,15.9l.83.69-.74.77c-.43.45-10.78,11.11-26.9,16.6-5.21,1.78-11.38,3.09-18.21,3.09ZM245.65,299.61c18.28,17.07,38.03,22.15,58.72,15.1,13.23-4.51,22.65-12.8,25.33-15.33-20.53-16.76-40.93-21.76-60.67-14.87-12.7,4.43-21.08,12.66-23.38,15.11Z"/>
        <path fill="#201e1d" d="M329.94,290.08c-17.93-15.8-37.88-20.62-59.29-14.33-16.04,4.71-26.93,14.23-27.04,14.33l-1.33-1.5c.45-.4,11.28-9.88,27.73-14.73,15.22-4.49,38.2-5.57,61.25,14.73l-1.32,1.5Z"/>
        <circle fill="#201e1d" cx="287.22" cy="292.79" r="12.1"/>
      </svg>
      <span class="wordmark">FULL SCOPE MEDIA</span>
    </div>
    <nav class="links">
      <a href="#work">Work</a>
      <a href="#services">Services</a>
      <a href="#contact">Contact</a>
      <button class="ghost" onclick={() => revealKey++}>Replay</button>
    </nav>
  </header>

  <div class="hero">
    <div class="kicker">PHOTOGRAPHY · WEB · SYSTEMS &amp; DATA</div>
    <h1>We see the whole picture.</h1>
    <p class="sub">One studio for everything your brand needs to be seen — photography, web design &amp; build, and the systems that tie it all together.</p>
    <div class="ctas">
      <button class="primary">Start a project</button>
      <button class="secondary">See our work</button>
    </div>
  </div>

  <div class="services" id="services">
    <div class="service">
      <div class="num">01</div>
      <div class="name">Photography</div>
      <p>Product, brand, and on-location shoots — imagery your identity can stand on.</p>
    </div>
    <div class="service">
      <div class="num">02</div>
      <div class="name">Web design &amp; build</div>
      <p>Sites designed and shipped end-to-end — fast, findable, built to convert.</p>
    </div>
    <div class="service">
      <div class="num">03</div>
      <div class="name">Systems &amp; data</div>
      <p>Integrations that connect your tools so the whole operation runs as one.</p>
    </div>
  </div>
</div>

<style>
  .root {
    display: flex;
    flex-direction: column;
    min-height: 100dvh;
    background: #f3f2f2;
    font-family: 'Archivo', sans-serif;
    color: #201e1d;
  }

  .nav {
    display: flex; align-items: center; justify-content: space-between;
    height: 78px; padding: 0 48px; border-bottom: 2px solid #201e1d; flex-shrink: 0;
  }
  .brand { display: flex; align-items: center; gap: 14px; }
  .mark { width: 46px; display: block; }
  .wordmark { font-weight: 700; font-size: 17px; letter-spacing: 0.14em; white-space: nowrap; }
  .links { display: flex; align-items: center; gap: 32px; font-size: 15px; font-weight: 600; }
  .links a { color: #201e1d; text-decoration: none; }
  .links a:hover { color: #ec3013; }

  button { border-radius: 0; cursor: pointer; font-family: inherit; }
  .ghost {
    border: 2px solid #201e1d; background: transparent; color: #201e1d;
    font-weight: 600; font-size: 13px; padding: 8px 14px;
  }
  .ghost:hover { background: #201e1d; color: #fff; }

  .hero {
    flex: 1; display: flex; flex-direction: column; justify-content: center;
    gap: 26px; padding: 48px;
  }
  .kicker { font-weight: 600; font-size: 14px; letter-spacing: 0.28em; color: #ec3013; }
  h1 {
    margin: 0; font-weight: 700; font-size: clamp(44px, 6.2vw, 100px);
    line-height: 1.02; letter-spacing: -0.02em; max-width: 1100px; text-wrap: pretty;
  }
  .sub { margin: 0; font-size: clamp(16px, 1.4vw, 22px); line-height: 1.5; color: #4a4744; max-width: 640px; text-wrap: pretty; }
  .ctas { display: flex; flex-wrap: wrap; gap: 16px; }
  .primary {
    display: inline-flex; justify-content: flex-start; background: #ec3013; color: #fff;
    border: none; font-weight: 600; font-size: 17px; padding: 16px 26px; min-width: 200px;
  }
  .primary:hover { background: #c62a10; }
  .secondary {
    display: inline-flex; justify-content: flex-start; background: transparent; color: #201e1d;
    border: 2px solid #201e1d; font-weight: 600; font-size: 17px; padding: 14px 26px;
  }
  .secondary:hover { background: #201e1d; color: #fff; }

  .services { display: grid; grid-template-columns: 1fr 1fr 1fr; border-top: 2px solid #201e1d; flex-shrink: 0; }
  .service { display: flex; flex-direction: column; gap: 10px; padding: 28px 48px 32px 40px; border-right: 2px solid #201e1d; }
  .service:first-child { padding-left: 48px; }
  .service:last-child { border-right: none; }
  .num { font-weight: 700; font-size: 14px; color: #ec3013; }
  .name { font-weight: 700; font-size: 21px; }
  .service p { margin: 0; font-size: 15px; line-height: 1.5; color: #4a4744; text-wrap: pretty; }

  /* ---------- mobile ---------- */
  @media (max-width: 720px) {
    .nav { padding: 0 20px; height: 64px; }
    .wordmark { font-size: 14px; }
    .mark { width: 38px; }
    .links { gap: 18px; font-size: 14px; }
    .links a:not(:first-child) { display: none; } /* keep it tight: Work + Replay */
    .hero { padding: 32px 20px; gap: 20px; }
    .ctas .primary, .ctas .secondary { width: 100%; min-width: 0; }
    .services { grid-template-columns: 1fr; }
    .service { border-right: none; border-bottom: 2px solid #201e1d; padding: 22px 20px !important; }
    .service:last-child { border-bottom: none; }
  }
</style>
